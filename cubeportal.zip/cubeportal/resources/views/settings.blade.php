@include('layout.partials.settings-header')
<!-- Page Wrapper -->
<div class="page-wrapper">
	<!-- Page Content -->
	<div class="content container-fluid">
		<div class="page-header">
			<div class="row align-items-center">
				<div class="col">
					<h3 class="page-title">Companies</h3>
					<ul class="breadcrumb">
						<li class="breadcrumb-item"><a href="index">Dashboard</a></li>
						<li class="breadcrumb-item active">Companies</li>
					</ul>
				</div>
				<div class="col-auto float-right ml-auto"> <a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_companydetails"><i class="fa fa-plus"></i> Add new</a> </div>
			</div>
		</div>
		@foreach($Companies as $Company)
		<div class="card mb-3">
			<div class="card-body">
				<div class="row">
					<div class="col-md-12">
						<div class="profile-view">
							<div class="profile-img-wrap flex-center">
								<div class="profile-img  flex-center">
									<a href="#"><img alt="" src="{{ $Company->image_path.'/'.$Company->company_image }}" class="img-fluid rounded-0"></a>
								</div>
							</div>
							<div class="profile-basic">
								<div class="row align-items-center">
									<div class="col-md-5">
										<div class="profile-info-left">
											<h3 class="user-name pr-2">{{ $Company->company_name }}</h3>
											<!-- <div class="staff-id"> Code : {{ $Company->company_code }}</div> -->
											<div class="text line-height-28">{{ $Company->mobile_number }}</div>
											<div class="text line-height-28">{{ $Company->email }}</div>
											<div><a href="{{ $Company->website_url }}" class="text line-height-28 mt-1" target="-blank">{{ $Company->website_url }}</a></div>

										</div>
									</div>
									<div class="col-md-7">
										<ul class="personal-info">
											<li class="clearfix">
												<div class="title">Contact person:</div>
												<div class="text line-height-28"><a href="" class="text line-height-28">{{ $Company->contact_person }}</a></div>
											</li>
											<li class="clearfix">
												<div class="title">Phone:</div>
												<div class="text line-height-28"><a href="" class="text line-height-28">{{ $Company->phone_number }}</div>

											</li>

											<li class="clearfix">
												<div class="title">Fax</div>
												<div class="text line-height-28">{{ $Company->fax }}</div>
											</li>

											<li class="clearfix">
												<div class="title">Address:</div>
												<div class="text line-height-28">{{ $Company->door_no.',' }}
													{{ $Company->country.','.$Company->state.','.$Company->city.'-'.$Company->postal_code.'.' }}
												</div>
											</li>
										</ul>
									</div>
								</div>
							</div>
							<div class="pro-edit"><a href="{{ route('editRecord', $Company->id) }}" class="edit-icon"><i class="fa fa-pencil"></i></a></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		@endforeach
		{{ $Companies->links() }}
	</div>
	<div id="add_companydetails" class="modal custom-modal fade" style="display: none;" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered modal-lg addsales" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title text-left">Create Company details</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
				</div>
				<div class="modal-body">
					<form action="{{ route('addRecord') }}" method="post" enctype="multipart/form-data">
						@csrf

						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label>Company Name <span class="text-danger">*</span></label>
									<input class="form-control @error('company_name') is-invalid @enderror" type="text" name="company_name" value="{{ old('company_name') }}">
									@error('company_name')
									<span class="invalid-feedback" role="alert">
										<strong>{{ $message }}</strong>
									</span>
									@enderror
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>Contact person <span class="text-danger">*</span></label>
									<input class="form-control @error('contact_person') is-invalid @enderror" type="text" name="contact_person" value="{{ old('contact_person') }}">
									@error('contact_person')
									<span class="invalid-feedback" role="alert">
										<strong>{{ $message }}</strong>
									</span>
									@enderror
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label>Company code <span class="text-danger">*</span></label>
									<input class="form-control @error('company_code') is-invalid @enderror" type="text" name="company_code" value="{{ old('company_code') }}">
									@error('company_code')
									<span class="invalid-feedback" role="alert">
										<strong>{{ $message }}</strong>
									</span>
									@enderror
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>Website url <span class="text-danger">*</span></label>
									<input class="form-control @error('website_url') is-invalid @enderror" type="text" name="website_url" value="{{ old('website_url') }}">
									@error('website_url')
									<span class="invalid-feedback" role="alert">
										<strong>{{ $message }}</strong>
									</span>
									@enderror
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Address</label>
									<input class="form-control @error('door_no') is-invalid @enderror" type="text" name="door_no" value="{{ old('door_no') }}">
									@error('door_no')
									<span class="invalid-feedback" role="alert">
										<strong>{{ $message }}</strong>
									</span>
									@enderror
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>Postal Code</label>
									<input class="form-control @error('postal_code') is-invalid @enderror pincode-api" type="text" name="postal_code" value="{{ old('postal_code') }}">
									@error('postal_code')
									<span class="invalid-feedback" role="alert">
										<strong>{{ $message }}</strong>
									</span>
									@enderror
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>Country</label>
									<div class="form-group">
										<input class="form-control required country-api" id="country-field" type="text" name="country" readonly>
									</div>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>State/Province</label>
									<div class="form-group">
										<input class="form-control required state-api" type="text" id="state-field" name="state" readonly>
									</div>

								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>City</label>
									<div class="form-group">
										<input class="form-control required city-api" type="text" id="city-field" name="city" readonly>
									</div>
								</div>
							</div>

							
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label>Landline Number <span class="text-danger">*</span></label>
									<input class="form-control @error('phone_number') is-invalid @enderror" type="text" name="phone_number" value="{{ old('phone_number') }}">
									@error('phone_number')
									<span class="invalid-feedback" role="alert">
										<strong>{{ $message }}</strong>
									</span>
									@enderror
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>Mobile Number <span class="text-danger">*</span></label>
									<input class="form-control @error('mobile_number') is-invalid @enderror" type="text" name="mobile_number" value="{{ old('mobile_number') }}">
									@error('mobile_number')
									<span class="invalid-feedback" role="alert">
										<strong>{{ $message }}</strong>
									</span>
									@enderror
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>Email <span class="text-danger">*</span></label>
									<input class="form-control @error('email') is-invalid @enderror" type="text" name="email" value="{{ old('email') }}">
									@error('email')
									<span class="invalid-feedback" role="alert">
										<strong>{{ $message }}</strong>
									</span>
									@enderror
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>Fax Number <span class="text-danger">*</span></label>
									<input class="form-control @error('fax') is-invalid @enderror" type="text" name="fax" value="{{ old('fax') }}">
									@error('fax')
									<span class="invalid-feedback" role="alert">
										<strong>{{ $message }}</strong>
									</span>
									@enderror
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label>Company Profile <span class="text-danger">*</span></label>
									<input class="form-control @error('company_image') is-invalid @enderror" type="file" name="company_image">
									@error('company_image')
									<span class="invalid-feedback" role="alert">
										<strong>{{ $message }}</strong>
									</span>
									@enderror
								</div>
							</div>
						</div>
						<div class="submit-section">
							<button class="btn btn-primary submit-btn">Save Changes</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<!-- /Page Wrapper -->
</div>
<!-- /Main Wrapper -->
<!-- jQuery -->
@include('layout.partials.footer-scripts')