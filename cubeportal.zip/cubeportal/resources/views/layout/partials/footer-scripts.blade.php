<!-- jQuery -->
<script src="{{ url('/js/jquery-3.5.1.min.js') }}"></script>
<!-- Bootstrap Core JS -->
<script src="{{ url('/js/popper.min.js')  }} "></script>
<script src="{{ url('/js/bootstrap.min.js') }}"></script>
<!-- Slimscroll JS -->
<script src="{{ url('/js/jquery.slimscroll.min.js') }}"></script>
@if(Route::is(['jobs-dashboard','user-dashboard']))
<!-- Chart JS -->
<script src="{{ url('/js/chart.min.js') }}"></script>
<script src="{{ url('/js/line-chart.js') }}"></script>
@endif
<!-- Select2 JS -->
<script src="{{ url('/js/select2.min.js') }}"></script>
<script src="{{ url('/js/jquery-ui.min.js') }}"></script>
<script src="{{ url('/js/jquery.ui.touch-punch.min.js') }}"></script>
<!-- Datetimepicker JS -->
<script src="{{ url('/js/moment.min.js') }}"></script>
<script src="{{ url('/js/jquery.datetimepicker.full.min.js') }}"></script>
<!-- <script src="{{ url('/js/bootstrap-datetimepicker.min.js') }}"></script> -->
<!-- Calendar JS -->
<script src="{{ url('/js/jquery-ui.min.js') }}"></script>
<script src="{{ url('/js/fullcalendar.min.js') }}"></script>
<script src="{{ url('/js/jquery.fullcalendar.js') }}"></script>
<!-- Multiselect JS -->
<script src="{{ url('/js/multiselect.min.js') }}"></script>
<!-- Datatable JS -->
<script src="{{ url('/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ url('/js/dataTables.bootstrap4.min.js') }}"></script>
<!-- Summernote JS -->
<script src="{{ url('/plugins/summernote/dist/summernote-bs4.min.js') }}"></script>
<script src="{{ url('/plugins/sticky-kit-master/dist/sticky-kit.min.js') }}"></script>
<!-- Task JS -->
<script src="{{ url('/js/task.js') }}"></script>
<script src="{{ url('/js/validate.js') }}"></script>
<script src="{{ url('/js/jquery-steps.js') }}"></script>
<script src="jquery.datetimepicker.full.min.js"></script>

@if(Session::has('success'))
	<script>
		swal("Great Job!!!", "{!! session::get('success') !!}");
	</script>
@endif

<script>


	var form = $("#contac");
	form.validate({
		errorPlacement: function errorPlacement(error, element) {
			element.after(error);
		},
		rules: {
			confirm: {
				equalTo: "#password"
			},
			phone_number: {
				required: true,
				number: true,
				minlength: 10

			},
			role: {
				required: true,
			},
			gender: {
				required: true,
			},
			department: {
				required: true,
			},
			marital: {
				required: true,
			},
			account_no: {
				required: true,
				number: true,
				minlength: 8,

			},
			family_phone_number: {
				required: true,
				number: true,
				minlength: 10

			},
			family_aadhar_number: {
				required: true,
				number: true,
				minlength: 10,

			},
			alt_number: {
				number: true,
				minlength: 10

			},
			emp_permanent_pincode:
			{
				number: true,
				minlength: 4,
				maxlength:6,
			},
			residence_permanent_pincode:
			{
				number: true,
				minlength: 4,
				maxlength:6,
			}


		}
	});
	form.children("div").steps({
		headerTag: "h3",
		bodyTag: "section",
		transitionEffect: "slideLeft",
		onStepChanging: function(event, currentIndex, newIndex) {
			form.validate().settings.ignore = ":disabled,:hidden";
			return form.valid();
		},
		onFinishing: function(event, currentIndex) {
			form.validate().settings.ignore = ":disabled";
			return form.valid();
		},
		onFinished: function(event, currentIndex) {
			alert("Submitted!");
		}
	});
	$(document).ready(function() {
		function readURL(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.onload = function(e) {
					$("#imagePreview").css("background-image", "url(" + e.target.result + ")");
					$("#imagePreview").hide();
					$("#imagePreview").fadeIn(650);
				};
				reader.readAsDataURL(input.files[0]);
			}
		}
		$("#imageUpload").change(function() {
			readURL(this);
		});
		var html = '<tr><td class="p-0"><div class="form-group mb-0"><select class="form-control required" name="family_relationship[]"><option value="">-- Select --</option><option value="Father">Father</option><option value="Mother">Mother</option><option value="Sister">Sister</option><option value="Brother">Brother</option><option value="Daughter">Daughter</option><option value="Emergency">Emergency</option><option value="Emergency">Son</option></select></div></div></td><td class="p-0"><div class="form-group mb-0"><input class="form-control required" name="family_person_name[]"></div></td><td class="p-0"><div class="form-group mb-0"><div class="cal"><input class="form-control datepicker" type="date" name="family_dob[]"></div></div></td><td class="p-0"><div class="form-group mb-0"><input class="form-control" name="family_phone_number[]"></div></td><td class="p-0"><div class="form-group mb-0"><input class="form-control required" name="family_occupation[]"></div></td><td class="p-0"><div class="form-group mb-0"><input class="form-control" name="family_aadhar_number[]"></div></td><td class="p-0"><div class="form-group mb-0"><input class="form-control" type="file" name="family_aadhar_file[]"></div></td><td class="p-0"></td></tr>';
		$("#addProduct").click(function() {
			$('.familybody').append(html);
		});
		$(document).on('click', '.remove', function() {
			$(this).parents('tr').remove();
		});
		var education = '<tr><td class="p-0"><div class="form-group mb-0"><input class="form-control required" name="degree[]"></div></td><td class="p-0"><div class="form-group mb-0"><input class="form-control required" name="institute[]"></div></td><td class="p-0"><div class="form-group mb-0"><input class="form-control required" name="university_board[]"></div></td><td class="p-0"><div class="form-group mb-0"><input class="form-control required" name="year_passed_out[]"></div></td><td class="p-0"><div class="form-group mb-0"><input class="form-control required" name="percentage[]"></div></td><td class="p-0 align-middle text-center"><a class="btn btn-danger text-white remove"><i class="fa fa-times" aria-hidden="true"></i></a></td></tr>';
		$("#addeducation").click(function() {
			$('.education-body').append(education);
		});
		$(document).on('click', '.remove', function() {
			$(this).parents('tr').remove();
		});
		var experience = '<div class="card"><div class="card-body"><h3 class="card-title">Experience Informations <a href="javascript:void(0);" class="delete-icon"><i class="fa fa-trash-o"></i></a></h3><div class="row"><div class="col-md-4"><div class="form-group"><label class="col-form-label">Company name <span class="text-danger">*</span></label><input class="form-control required" name="exp_company_name[]"></div></div><div class="col-md-4"><div class="form-group"><label class="col-form-label">Location <span class="text-danger">*</span></label><input class="form-control required" name="exp_location[]"></div></div><div class="col-md-4"><div class="form-group"><label class="col-form-label">Job Position <span class="text-danger">*</span></label><input class="form-control required" name="exp_position[]"></div></div><div class="col-md-4"><div class="form-group"><label class="col-form-label">Period From <span class="text-danger">*</span></label><div class="cal"><input type="date" class="form-control required" name="exp_period_from[]"></div></div></div><div class="col-md-4"><div class="form-group"><label class="col-form-label">Period To <span class="text-danger">*</span></label><div class="cal"><input type="date" class="form-control required" name="exp_period_to[]"></div></div></div><div class="col-md-4"><div class="form-group"><div><label class="col-form-label">File <span class="text-danger">*</span></label><input type="file" class="form-control required" name="experience_file[]"></div></div></div></div></div></div>';
		$(".add-more").click(function() {
			$('.card-append').append(experience);
		});
		$(document).on('click', '.delete-icon', function() {
			$(this).parents('.card').remove();
		});
		var idproof = '<tr><td class="p-0"><div class="form-group mb-0"><select class="form-control select required" name="emp_card_type[]"><option>Select</option><option value="Pancard">Pan card</option><option value="Aadhar">Aadhar</option><option value="Passport">Passport</option><option value="Education Documents">Education Documents</option></select></div></td><td class="p-0"><div class="form-group mb-0"><input class="form-control required" name="emp_card_number[]"></div></td><td class="p-0"><div class="form-group mb-0"><input class="form-control required" type="file" name="emp_upload_file[]"></div></td><td class="p-0"></td></tr>';
		$("#addproof").click(function() {
			$('.proof').append(idproof);
		});
		$(document).on('click', '.remove', function() {
			$(this).parents('tr').remove();
		});



		//set initial state.
		$('#yesorno').change(function() {
			if ($(this).is(":checked")) {
				$('.form-ex').css('display', 'block');
			} else {
				$('.form-ex').css('display', 'none');
			}
			$('#textbox1').val($(this).is(':checked'));
		});

		//set initial state.
		$('#staff_module').change(function() {
			if ($(this).is(":checked")) {
				$('.residence').css('display', 'none');
			} else {
				$('.residence').css('display', 'block');
			}
			$('#textbox1').val($(this).is(':checked'));
		});

	
		$('.pincode-api').keyup(function() {
			var pincode = $('.pincode-api').val();
			$.ajax({
					url: "https://api.postalpincode.in/pincode/" + pincode,
					dataType: "json",
					type: "GET",
					success: function(result, success) {
						//debugger;
						$('.city-api').val('');
						$('.state-api').val('');
						$('.country-api').val('');
						$('.city-api').val(result[0].PostOffice[0].District);
						$('.state-api').val(result[0].PostOffice[0].State);
						$('.country-api').val(result[0].PostOffice[0].Country);
					}
				});
		});
		
		$('.pincode-permanent-api').keyup(function() {
			var pincodes = $('.pincode-permanent-api').val();
			$.ajax({
					url: "https://api.postalpincode.in/pincode/" + pincodes,
					dataType: "json",
					type: "GET",
					success: function(result, success) {
						//debugger;
						$('.city-permanent-api').val('');
						$('.state-permanent-api').val('');
						$('.country-permanent-api').val('');
						$('.city-permanent-api').val(result[0].PostOffice[0].District);
						$('.state-permanent-api').val(result[0].PostOffice[0].State);
						$('.country-permanent-api').val(result[0].PostOffice[0].Country);
					}
				});
		});

		$('.btn-pin').click(function(){
			var pincode = $('.city-api').val();
			alert(pincode);
		});

		$('.timepicker').datetimepicker(
			{

				datepicker:false,
  				format:'H:m a'
			}
		);

		$('.datepicker').datetimepicker(
			{
				timepicker:false,
 				format:'d/m/Y',

			}
		);
     $('#check-address').click(function(){ 
     if ($('#check-address').is(":checked")) {
      $('#door-field1').val($('#door-field').val());
	  $('#street-field1').val($('#street-field').val());
	  $('#pincode-field1').val($('#pincode-field').val());
	  $('#state-field1').val($('#state-field').val());
	  $('#city-field1').val($('#city-field').val());
	  $('#country-field1').val($('#country-field').val());

     } 
	 
	 else {
      $('#field').val("");
      $('#door-field1').val($('').val());
	  $('#street-field1').val($('').val());
	  $('#pincode-field1').val($('').val());
	  $('#state-field1').val($('').val());
	  $('#city-field1').val($('').val());
	  $('#country-field1').val($('').val());
     };
    });
 
   });


</script>

@if (count($errors) > 0)
    <script type="text/javascript">
        $( document ).ready(function() {
             $('#add_companydetails').modal('show');
        });
    </script>
  @endif
<!-- Dropfiles JS
		<script src="js/dropfiles.js"></script> -->
<!-- Custom JS -->

<!--End Custom Script CU0219 -->
<script>
	$(document).ready(function() {
		// Read value on page load
		$("#result b").html($("#customRange").val());
		// Read value on change
		$("#customRange").change(function() {
			$("#result b").html($(this).val());
		});
	});
	$(".header").stick_in_parent({});
	// This is for the sticky sidebar    
	$(".stickyside").stick_in_parent({
		offset_top: 60
	});
	$('.stickyside a').click(function() {
		$('html, body').animate({
			scrollTop: $($(this).attr('href')).offset().top - 60
		}, 500);
		return false;
	});
	// This is auto select left sidebar
	// Cache selectors
	// Cache selectors
	var lastId,
		topMenu = $(".stickyside"),
		topMenuHeight = topMenu.outerHeight(),
		// All list items
		menuItems = topMenu.find("a"),
		// Anchors corresponding to menu items
		scrollItems = menuItems.map(function() {
			var item = $($(this).attr("href"));
			if (item.length) {
				return item;
			}
		});
	// Bind click handler to menu items
	// Bind to scroll
	$(window).scroll(function() {
		// Get container scroll position
		var fromTop = $(this).scrollTop() + topMenuHeight - 250;
		// Get id of current scroll item
		var cur = scrollItems.map(function() {
			if ($(this).offset().top < fromTop) return this;
		});
		// Get the id of the current element
		cur = cur[cur.length - 1];
		var id = cur && cur.length ? cur[0].id : "";
		if (lastId !== id) {
			lastId = id;
			// Set/remove active class
			menuItems.removeClass("active").filter("[href='#" + id + "']").addClass("active");
		}
	});
	$(function() {
		$(document).on("click", '.btn-add-row', function() {
			var id = $(this).closest("table.table-review").attr('id'); // Id of particular table
			console.log(id);
			var div = $("<tr />");
			div.html(GetDynamicTextBox(id));
			$("#" + id + "_tbody").append(div);
		});
		$(document).on("click", "#comments_remove", function() {
			$(this).closest("tr").prev().find('td:last-child').html('<button type="button" class="btn btn-danger" id="comments_remove"><i class="fa fa-trash-o"></i></button>');
			$(this).closest("tr").remove();
		});

		function GetDynamicTextBox(table_id) {
			$('#comments_remove').remove();
			var rowsLength = document.getElementById(table_id).getElementsByTagName("tbody")[0].getElementsByTagName("tr").length + 1;
			return '<td>' + rowsLength + '</td>' + '<td><input type="text" name = "DynamicTextBox" class="form-control" value = "" ></td>' + '<td><input type="text" name = "DynamicTextBox" class="form-control" value = "" ></td>' + '<td><input type="text" name = "DynamicTextBox" class="form-control" value = "" ></td>' + '<td class="align-middle"><a type="button" class="btn btn-danger text-white" id="comments_remove"><i class="fa fa-trash-o"></i></a></td>'
		}
	});
</script>

<script src="{{ url('js/app.js') }}"></script>