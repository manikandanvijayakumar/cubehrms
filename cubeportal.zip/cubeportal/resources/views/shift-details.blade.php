@include('layout.partials.header')
<!-- Page Wrapper -->
<div class="page-wrapper">

    <div class="content container-fluid">
        <div class="page-header">

            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Shift Details</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index">Dashboard</a></li>
                        <li class="breadcrumb-item active">Shift Details</li>
                    </ul>
                </div>
                <div class="col-auto float-right ml-auto">
                    <a href="#" class="btn add-btn" data-toggle="modal" data-target="#add"><i class="fa fa-plus"></i> Add new</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <!-- Page Header -->
                <div class="page-header">
                    <div class="row">
                        <div class="col-sm-12">
                            <h3 class="page-title">Shift Details</h3>
                        </div>
                    </div>
                </div>
                <!-- /Page Header -->
                <div class="table-responsive">
                    <table class="table table-bordered mb-0">
                        <thead>
                            <tr>
                                <th>S.No</th>
                                <th>Shift name</th>
                                <th>In time</th>
                                <th>Out time</th>
                                <th>In time (min)</th>
                                <th>In time (max)</th>
                                <th>Out time (min)</th>
                                <th>Out time (max)</th>
                                <th>Status</th>


                            </tr>
                        </thead>
                        <tbody>
                            @foreach($shifts as $shift)
                            <tr>
                                <td width="50px">{{ $shift->id }}</td>
                                <td>{{ $shift->shift_name }}</td>
                                <td>{{ $shift->in_time }}</td>
                                <td>{{ $shift->out_time }}</td>
                                <td>{{ $shift->min_in_time }}</td>
                                <td>{{ $shift->max_in_time }}</td>
                                <td>{{ $shift->min_out_time }}</td>
                                <td>{{ $shift->max_out_time }}</td>
                                <td>
                                    <div class="action-label">
                                        @if($shift->status === 1)
                                        <a class="btn btn-white btn-sm btn-rounded" href="javascript:void(0);">
                                            <i class="fa fa-dot-circle-o text-success"></i> Active
                                        </a>
                                        @else
                                        <a class="btn btn-white btn-sm btn-rounded" href="javascript:void(0);">
                                            <i class="fa fa-dot-circle-o text-danger"></i> In Active
                                        </a>
                                        @endif

                                    </div>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Page Wrapper -->

<div id="add" class="modal custom-modal fade" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add Shift</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="{{ route('createshift') }}" method="post" autocomplete="off">
                    @csrf
                    <div class="form-group">
                        <label>Shift Name <span class="text-danger">*</span></label>
                        <input class="form-control @error('shift') is-invalid @enderror" type="text" name="shift_name">
                        @error('shift')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>In time <span class="text-danger">*</span></label>
                                <input class="form-control timepicker @error('shift') is-invalid @enderror" name="in_time">
                                @error('shift')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Out time <span class="text-danger">*</span></label>
                                <input class="form-control  timepicker  @error('shift') is-invalid @enderror" type="text" name="out_time">
                                @error('shift')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>In time (min) <span class="text-danger">*</span></label>
                                <input class="form-control  timepicker  @error('shift') is-invalid @enderror" type="text" name="min_in_time">
                                @error('shift')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>In time (max) <span class="text-danger">*</span></label>
                                <input class="form-control  timepicker  @error('shift') is-invalid @enderror" type="text" name="max_in_time">
                                @error('shift')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Out time (Min) <span class="text-danger">*</span></label>
                                <input class="form-control  timepicker  @error('shift') is-invalid @enderror" type="text" name="min_out_time">
                                @error('shift')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Out time (Max) <span class="text-danger">*</span></label>
                                <input class="form-control  timepicker  @error('shift') is-invalid @enderror" type="text" name="max_out_time">
                                @error('shift')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>

                    </div>
                    <div class="submit-section">
                        <button class="btn btn-primary submit-btn">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


@include('layout.partials.footer-scripts')