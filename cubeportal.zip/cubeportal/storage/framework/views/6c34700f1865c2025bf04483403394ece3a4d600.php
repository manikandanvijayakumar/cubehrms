<div class="sidebar" id="sidebar">
			<div class="sidebar-inner slimscroll">
				<div class="sidebar-menu">
					<ul>
						<li class="<?php echo e(Request::is('index') ? 'active' : ''); ?>"> <a href="<?php echo e(url('index')); ?>"><i class="la la-home"></i> <span>Back to Home</span> </a> </li>
						<li class="menu-title">Settings</li>
						<li class="<?php echo e(Request::is('settings') ? 'active' : ''); ?>"> <a href="<?php echo e(url('settings')); ?>"><i class="la la-building"></i><span>Company Settings</span> </a> </li>
						<li class="<?php echo e(Request::is('localization') ? 'active' : ''); ?>"> <a href="<?php echo e(url('localization')); ?>"><i class="la la-clock-o"></i><span>Localization</span> </a> </li>
						<li class="<?php echo e(Request::is('theme-settings') ? 'active' : ''); ?>"> <a href="<?php echo e(url('theme-settings')); ?>"><i class="la la-photo"></i><span>Theme Settings</span> </a> </li>
						<li class="<?php echo e(Request::is('roles-permissions') ? 'active' : ''); ?>"> <a href="<?php echo e(url('roles-permissions')); ?>"><i class="la la-key"></i> <span>Roles & Permissions</span> </a> </li>
						<li class="<?php echo e(Request::is('email-settings') ? 'active' : ''); ?>"> <a href="<?php echo e(url('email-settings')); ?>"><i class="la la-at"></i><span>Email Settings</span> </a> </li>
						<li class="<?php echo e(Request::is('performance-setting') ? 'active' : ''); ?>"> <a href="<?php echo e(url('performance-setting')); ?>"><i class="la la-bar-chart"></i> <span>Performance Settings</span></a> </li>
						<li class="<?php echo e(Request::is('approval-setting') ? 'active' : ''); ?>"> <a href="<?php echo e(url('approval-setting')); ?>"><i class="la la-thumbs-up"></i> <span>Approval Settings</span></a> </li>
						<li class="<?php echo e(Request::is('invoice-settings') ? 'active' : ''); ?>"> <a href="<?php echo e(url('invoice-settings')); ?>"><i class="la la-pencil-square"></i><span>Invoice Settings</span> </a> </li>
						<li class="<?php echo e(Request::is('salary-settings') ? 'active' : ''); ?>"> <a href="<?php echo e(url('salary-settings')); ?>"><i class="la la-money"></i> <span>Salary Settings</span> </a> </li>
						<li class="<?php echo e(Request::is('notifications-settings') ? 'active' : ''); ?>"> <a href="<?php echo e(url('notifications-settings')); ?>"><i class="la la-globe"></i><span>Notifications</span> </a> </li>
						<li class="<?php echo e(Request::is('change-password') ? 'active' : ''); ?>"> <a href="<?php echo e(url('change-password')); ?>"><i class="la la-lock"></i><span>Change Password</span> </a> </li>
						<li class="<?php echo e(Request::is('leave-type') ? 'active' : ''); ?>"> <a href="<?php echo e(url('leave-type')); ?>"><i class="la la-cogs"></i> <span>Leave Type </span> </a> </li>
						<li class="<?php echo e(Request::is('toxbox-setting') ? 'active' : ''); ?>"> <a href="<?php echo e(url('toxbox-setting')); ?>"><i class="la la-comment"></i> <span>ToxBox Settings</span></a> </li>
						<li class="<?php echo e(Request::is('cron-setting') ? 'active' : ''); ?>"> <a href="<?php echo e(url('cron-setting')); ?>"><i class="la la-rocket"></i> <span>Cron Settings</span></a> </li>
					</ul>
				</div>
			</div>
		</div><?php /**PATH D:\xampp\htdocs\cubeportal\resources\views/layout/partials/settings-sidebar.blade.php ENDPATH**/ ?>