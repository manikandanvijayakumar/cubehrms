<!DOCTYPE html>
<html lang="en">
  <head>
    <?php echo $__env->make('layout.partials.settings-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>

  <body>

 <?php echo $__env->make('layout.partials.settings-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('layout.partials.settings-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <?php echo $__env->yieldContent('content'); ?>
 <?php echo $__env->make('layout.partials.settings-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  </body>
</html><?php /**PATH D:\xampp\htdocs\cubeportal\resources\views/layout/settings-layout.blade.php ENDPATH**/ ?>