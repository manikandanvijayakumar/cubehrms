<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
	<meta name="description" content="Smarthr - Bootstrap Admin Template">
	<meta name="keywords" content="admin, estimates, bootstrap, business, corporate, creative, management, minimal, modern, accounts, invoice, html5, responsive, CRM, Projects">
	<meta name="author" content="Dreamguys - Bootstrap Admin Template">
	<meta name="robots" content="noindex, nofollow">
	<title>Settings - HRMS admin template</title>
	<!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="img/favicon.png">
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Fontawesome CSS -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Lineawesome CSS -->
	<link rel="stylesheet" href="css/line-awesome.min.css">
	<!-- Select2 CSS -->
	<link rel="stylesheet" href="css/select2.min.css">
	<!-- Main CSS -->
	<link rel="stylesheet" href="css/style.css">
</head>

<body>
	<!-- Main Wrapper -->
	<div class="main-wrapper">
		<!-- Header -->
		<div class="header">
			<!-- Logo -->
			<div class="header-left">
				<a href="index" class="logo"> <img src="img/logo.png" width="40" height="40" alt=""> </a>
			</div>
			<!-- /Logo -->
			<a id="toggle_btn" href="javascript:void(0);"> <span class="bar-icon">
					<span></span> <span></span> <span></span> </span>
			</a>
			<!-- Header Title -->
			<div class="page-title-box">
				<h3>Dreamguy's Technologies</h3>
			</div>
			<!-- /Header Title --><a id="mobile_btn" class="mobile_btn" href="#sidebar"><i class="fa fa-bars"></i></a>
			<!-- Header Menu -->
			<ul class="nav user-menu">
				<!-- Search -->
				<li class="nav-item">
					<div class="top-nav-search">
						<a href="javascript:void(0);" class="responsive-search"> <i class="fa fa-search"></i> </a>
						<form action="search">
							<input class="form-control" type="text" placeholder="Search here">
							<button class="btn" type="submit"><i class="fa fa-search"></i></button>
						</form>
					</div>
				</li>
				<!-- /Search -->
				<!-- Flag -->
				<li class="nav-item dropdown has-arrow flag-nav">
					<a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button"> <img src="img/flags/us.png" alt="" height="20"> <span>English</span> </a>
					<div class="dropdown-menu dropdown-menu-right">
						<a href="javascript:void(0);" class="dropdown-item"> <img src="img/flags/us.png" alt="" height="16"> English </a>
						<a href="javascript:void(0);" class="dropdown-item"> <img src="img/flags/fr.png" alt="" height="16"> French </a>
						<a href="javascript:void(0);" class="dropdown-item"> <img src="img/flags/es.png" alt="" height="16"> Spanish </a>
						<a href="javascript:void(0);" class="dropdown-item"> <img src="img/flags/de.png" alt="" height="16"> German </a>
					</div>
				</li>
				<!-- /Flag -->
				<!-- Notifications -->
				<li class="nav-item dropdown">
					<a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown"> <i class="fa fa-bell-o"></i> <span class="badge badge-pill">3</span> </a>
					<div class="dropdown-menu notifications">
						<div class="topnav-dropdown-header"> <span class="notification-title">Notifications</span> <a href="javascript:void(0)" class="clear-noti"> Clear All </a> </div>
						<div class="noti-content">
							<ul class="notification-list">
								<li class="notification-message">
									<a href="activities">
										<div class="media"> <span class="avatar">
												<img alt="" src="img/profiles/avatar-02.jpg">
											</span>
											<div class="media-body">
												<p class="noti-details"><span class="noti-title">John Doe</span> added new task <span class="noti-title">Patient appointment booking</span></p>
												<p class="noti-time"><span class="notification-time">4 mins ago</span></p>
											</div>
										</div>
									</a>
								</li>
								<li class="notification-message">
									<a href="activities">
										<div class="media"> <span class="avatar">
												<img alt="" src="img/profiles/avatar-03.jpg">
											</span>
											<div class="media-body">
												<p class="noti-details"><span class="noti-title">Tarah Shropshire</span> changed the task name <span class="noti-title">Appointment booking with payment gateway</span></p>
												<p class="noti-time"><span class="notification-time">6 mins ago</span></p>
											</div>
										</div>
									</a>
								</li>
								<li class="notification-message">
									<a href="activities">
										<div class="media"> <span class="avatar">
												<img alt="" src="img/profiles/avatar-06.jpg">
											</span>
											<div class="media-body">
												<p class="noti-details"><span class="noti-title">Misty Tison</span> added <span class="noti-title">Domenic Houston</span> and <span class="noti-title">Claire Mapes</span> to project <span class="noti-title">Doctor available module</span></p>
												<p class="noti-time"><span class="notification-time">8 mins ago</span></p>
											</div>
										</div>
									</a>
								</li>
								<li class="notification-message">
									<a href="activities">
										<div class="media"> <span class="avatar">
												<img alt="" src="img/profiles/avatar-17.jpg">
											</span>
											<div class="media-body">
												<p class="noti-details"><span class="noti-title">Rolland Webber</span> completed task <span class="noti-title">Patient and Doctor video conferencing</span></p>
												<p class="noti-time"><span class="notification-time">12 mins ago</span></p>
											</div>
										</div>
									</a>
								</li>
								<li class="notification-message">
									<a href="activities">
										<div class="media"> <span class="avatar">
												<img alt="" src="img/profiles/avatar-13.jpg">
											</span>
											<div class="media-body">
												<p class="noti-details"><span class="noti-title">Bernardo Galaviz</span> added new task <span class="noti-title">Private chat module</span></p>
												<p class="noti-time"><span class="notification-time">2 days ago</span></p>
											</div>
										</div>
									</a>
								</li>
							</ul>
						</div>
						<div class="topnav-dropdown-footer"> <a href="activities">View all Notifications</a> </div>
					</div>
				</li>
				<!-- /Notifications -->
				<!-- Message Notifications -->
				<li class="nav-item dropdown">
					<a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown"> <i class="fa fa-comment-o"></i> <span class="badge badge-pill">8</span> </a>
					<div class="dropdown-menu notifications">
						<div class="topnav-dropdown-header"> <span class="notification-title">Messages</span> <a href="javascript:void(0)" class="clear-noti"> Clear All </a> </div>
						<div class="noti-content">
							<ul class="notification-list">
								<li class="notification-message">
									<a href="chat">
										<div class="list-item">
											<div class="list-left"> <span class="avatar">
													<img alt="" src="img/profiles/avatar-09.jpg">
												</span> </div>
											<div class="list-body"> <span class="message-author">Richard Miles </span> <span class="message-time">12:28 AM</span>
												<div class="clearfix"></div> <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
											</div>
										</div>
									</a>
								</li>
								<li class="notification-message">
									<a href="chat">
										<div class="list-item">
											<div class="list-left"> <span class="avatar">
													<img alt="" src="img/profiles/avatar-02.jpg">
												</span> </div>
											<div class="list-body"> <span class="message-author">John Doe</span> <span class="message-time">6 Mar</span>
												<div class="clearfix"></div> <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
											</div>
										</div>
									</a>
								</li>
								<li class="notification-message">
									<a href="chat">
										<div class="list-item">
											<div class="list-left"> <span class="avatar">
													<img alt="" src="img/profiles/avatar-03.jpg">
												</span> </div>
											<div class="list-body"> <span class="message-author"> Tarah Shropshire </span> <span class="message-time">5 Mar</span>
												<div class="clearfix"></div> <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
											</div>
										</div>
									</a>
								</li>
								<li class="notification-message">
									<a href="chat">
										<div class="list-item">
											<div class="list-left"> <span class="avatar">
													<img alt="" src="img/profiles/avatar-05.jpg">
												</span> </div>
											<div class="list-body"> <span class="message-author">Mike Litorus</span> <span class="message-time">3 Mar</span>
												<div class="clearfix"></div> <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
											</div>
										</div>
									</a>
								</li>
								<li class="notification-message">
									<a href="chat">
										<div class="list-item">
											<div class="list-left"> <span class="avatar">
													<img alt="" src="img/profiles/avatar-08.jpg">
												</span> </div>
											<div class="list-body"> <span class="message-author"> Catherine Manseau </span> <span class="message-time">27 Feb</span>
												<div class="clearfix"></div> <span class="message-content">Lorem ipsum dolor sit amet, consectetur adipiscing</span>
											</div>
										</div>
									</a>
								</li>
							</ul>
						</div>
						<div class="topnav-dropdown-footer"> <a href="chat">View all Messages</a> </div>
					</div>
				</li>
				<!-- /Message Notifications -->
				<li class="nav-item dropdown has-arrow main-drop">
					<a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown"> <span class="user-img"><img src="img/profiles/avatar-21.jpg" alt="">
							<span class="status online"></span></span> <span>Admin</span> </a>
					<div class="dropdown-menu"> <a class="dropdown-item" href="profile">My Profile</a> <a class="dropdown-item" href="settings">Settings</a> <a class="dropdown-item" href="login">Logout</a> </div>
				</li>
			</ul>
			<!-- /Header Menu -->
			<!-- Mobile Menu -->
			<div class="dropdown mobile-user-menu"> <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
				<div class="dropdown-menu dropdown-menu-right"> <a class="dropdown-item" href="profile">My Profile</a> <a class="dropdown-item" href="settings">Settings</a> <a class="dropdown-item" href="login">Logout</a> </div>
			</div>
			<!-- /Mobile Menu -->
		</div>
		<!-- /Header -->
		<!-- Sidebar -->
		<!-- Sidebar -->
		<div class="sidebar" id="sidebar">
			<div class="sidebar-inner slimscroll">
				<div class="sidebar-menu">
					<ul>
						<li class="<?php echo e(Request::is('index') ? 'active' : ''); ?>"> <a href="<?php echo e(url('index')); ?>"><i class="la la-home"></i> <span>Back to Home</span> </a> </li>
						<li class="menu-title">Settings</li>
						<li class="<?php echo e(Request::is('settings') ? 'active' : ''); ?>"> <a href="<?php echo e(url('settings')); ?>"><i class="la la-building"></i><span>Company Settings</span> </a> </li>
						<li class="<?php echo e(Request::is('localization') ? 'active' : ''); ?>"> <a href="<?php echo e(url('localization')); ?>"><i class="la la-clock-o"></i><span>Localization</span> </a> </li>
						<li class="<?php echo e(Request::is('theme-settings') ? 'active' : ''); ?>"> <a href="<?php echo e(url('theme-settings')); ?>"><i class="la la-photo"></i><span>Theme Settings</span> </a> </li>
						<li class="<?php echo e(Request::is('roles-permissions') ? 'active' : ''); ?>"> <a href="<?php echo e(url('roles-permissions')); ?>"><i class="la la-key"></i> <span>Roles & Permissions</span> </a> </li>
						<li class="<?php echo e(Request::is('email-settings') ? 'active' : ''); ?>"> <a href="<?php echo e(url('email-settings')); ?>"><i class="la la-at"></i><span>Email Settings</span> </a> </li>
						<li class="<?php echo e(Request::is('performance-setting') ? 'active' : ''); ?>"> <a href="<?php echo e(url('performance-setting')); ?>"><i class="la la-bar-chart"></i> <span>Performance Settings</span></a> </li>
						<li class="<?php echo e(Request::is('approval-setting') ? 'active' : ''); ?>"> <a href="<?php echo e(url('approval-setting')); ?>"><i class="la la-thumbs-up"></i> <span>Approval Settings</span></a> </li>
						<li class="<?php echo e(Request::is('invoice-settings') ? 'active' : ''); ?>"> <a href="<?php echo e(url('invoice-settings')); ?>"><i class="la la-pencil-square"></i><span>Invoice Settings</span> </a> </li>
						<li class="<?php echo e(Request::is('salary-settings') ? 'active' : ''); ?>"> <a href="<?php echo e(url('salary-settings')); ?>"><i class="la la-money"></i> <span>Salary Settings</span> </a> </li>
						<li class="<?php echo e(Request::is('notifications-settings') ? 'active' : ''); ?>"> <a href="<?php echo e(url('notifications-settings')); ?>"><i class="la la-globe"></i><span>Notifications</span> </a> </li>
						<li class="<?php echo e(Request::is('change-password') ? 'active' : ''); ?>"> <a href="<?php echo e(url('change-password')); ?>"><i class="la la-lock"></i><span>Change Password</span> </a> </li>
						<li class="<?php echo e(Request::is('leave-type') ? 'active' : ''); ?>"> <a href="<?php echo e(url('leave-type')); ?>"><i class="la la-cogs"></i> <span>Leave Type </span> </a> </li>
						<li class="<?php echo e(Request::is('toxbox-setting') ? 'active' : ''); ?>"> <a href="<?php echo e(url('toxbox-setting')); ?>"><i class="la la-comment"></i> <span>ToxBox Settings</span></a> </li>
						<li class="<?php echo e(Request::is('cron-setting') ? 'active' : ''); ?>"> <a href="<?php echo e(url('cron-setting')); ?>"><i class="la la-rocket"></i> <span>Cron Settings</span></a> </li>
					</ul>
				</div>
			</div>
		</div>
		<!-- Sidebar -->
		<!-- Page Wrapper -->
		<!-- Page Wrapper -->
		<div class="page-wrapper">
			<!-- Page Content -->
			<div class="content container-fluid">
				<div class="page-header">
					<div class="row align-items-center">
						<div class="col">
							<h3 class="page-title">Companies</h3>
							<ul class="breadcrumb">
								<li class="breadcrumb-item"><a href="index">Dashboard</a></li>
								<li class="breadcrumb-item active">Companies</li>
							</ul>
						</div>
						<div class="col-auto float-right ml-auto"> <a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_companydetails"><i class="fa fa-plus"></i> Add new</a> </div>
					</div>
				</div>
				<?php $__currentLoopData = $Companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="card mb-3">
					<div class="card-body">
						<div class="row">
							<div class="col-md-12">
								<div class="profile-view">
									<div class="profile-img-wrap flex-center">
										<div class="profile-img  flex-center">
											<a href="#"><img alt="" src="<?php echo e($Company->image_path.'/'.$Company->company_image); ?>" class="img-fluid rounded-0"></a>
										</div>
									</div>
									<div class="profile-basic">
										<div class="row align-items-center">
											<div class="col-md-5">
												<div class="profile-info-left">
													<h3 class="user-name pr-2"><?php echo e($Company->company_name); ?></h3>
													<!-- <div class="staff-id"> Code : <?php echo e($Company->company_code); ?></div> -->
													<div class="text line-height-28"><?php echo e($Company->mobile_number); ?></div>
													<div class="text line-height-28"><?php echo e($Company->email); ?></div>
													<div><a href="<?php echo e($Company->website_url); ?>" class="text line-height-28 mt-1" target="-blank"><?php echo e($Company->website_url); ?></a></div>

												</div>
											</div>
											<div class="col-md-7">
												<ul class="personal-info">
													<li  class="clearfix">
														<div class="title">Contact person:</div>
														<div class="text line-height-28"><a href="" class="text line-height-28"><?php echo e($Company->contact_person); ?></a></div>
													</li>
													<li class="clearfix">
														<div class="title">Phone:</div>
														<div class="text line-height-28"><a href="" class="text line-height-28"><?php echo e($Company->phone_number); ?></div>

													</li>
											
													<li class="clearfix">
														<div class="title">Fax</div>
														<div class="text line-height-28"><?php echo e($Company->fax); ?></div>
													</li>
												
													<li class="clearfix">
														<div class="title">Address:</div>
														<div class="text line-height-28"><?php echo e($Company->door_no.','); ?>

															<?php echo e($Company->country.','.$Company->state.','.$Company->city.'-'.$Company->postal_code.'.'); ?>

														</div>
													</li>
												</ul>
											</div>
										</div>
									</div>
									<div class="pro-edit"><a href="#" class="edit-icon"><i class="fa fa-pencil"></i></a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php echo e($Companies->links()); ?>

			</div>
			<div id="add_companydetails" class="modal custom-modal fade" style="display: none;" aria-hidden="true">
				<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title text-left">Create Company details</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
						</div>
						<div class="modal-body">
							<form action="<?php echo e(route('addRecord')); ?>" method="post" enctype="multipart/form-data">
								<?php echo csrf_field(); ?>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Company Profile <span class="text-danger">*</span></label>
											<input class="form-control <?php $__errorArgs = ['company_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" name="company_image" >
											<?php $__errorArgs = ['company_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Company Name <span class="text-danger">*</span></label>
											<input class="form-control <?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="company_name" value="<?php echo e(old('company_name')); ?>">
											<?php $__errorArgs = ['company_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Contact person <span class="text-danger">*</span></label>
											<input class="form-control <?php $__errorArgs = ['contact_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="contact_person" value="<?php echo e(old('contact_person')); ?>">
											<?php $__errorArgs = ['contact_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Company code <span class="text-danger">*</span></label>
											<input class="form-control <?php $__errorArgs = ['company_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="company_code" value="<?php echo e(old('company_code')); ?>">
											<?php $__errorArgs = ['company_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Website url <span class="text-danger">*</span></label>
											<input class="form-control <?php $__errorArgs = ['website_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="website_url" value="<?php echo e(old('website_url')); ?>">
											<?php $__errorArgs = ['website_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-12">
										<div class="form-group">
											<label>Address</label>
											<input class="form-control <?php $__errorArgs = ['door_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="door_no" value="<?php echo e(old('door_no')); ?>">
											<?php $__errorArgs = ['door_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label>Country</label>
											<select class="form-control select <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="country">
												<option>USA</option>
												<option>United Kingdom</option>
											</select>
											<?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label>City</label>
											<select class="form-control select <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="city">
												<option>Chennai</option>
												<option>Trichy</option>
											</select>
											<?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label>State/Province</label>
											<select class="form-control select <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="state">
												<option>California</option>
												<option>Alaska</option>
												<option>Alabama</option>
											</select>
											<?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
									<div class="col-md-3">
										<div class="form-group">
											<label>Postal Code</label>
											<input class="form-control <?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="postal_code" value="<?php echo e(old('postal_code')); ?>">
											<?php $__errorArgs = ['postal_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label>Phone Number <span class="text-danger">*</span></label>
											<input class="form-control <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="phone_number" value="<?php echo e(old('phone_number')); ?>">
											<?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Mobile Number <span class="text-danger">*</span></label>
											<input class="form-control <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="mobile_number" value="<?php echo e(old('mobile_number')); ?>">
											<?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Email <span class="text-danger">*</span></label>
											<input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="email" value="<?php echo e(old('email')); ?>">
											<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label>Fax Number <span class="text-danger">*</span></label>
											<input class="form-control <?php $__errorArgs = ['fax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="fax" value="<?php echo e(old('fax')); ?>">
											<?php $__errorArgs = ['fax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
											<span class="invalid-feedback" role="alert">
												<strong><?php echo e($message); ?></strong>
											</span>
											<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
										</div>
									</div>
								</div>
								<div class="submit-section">
									<button class="btn btn-primary submit-btn">Save Changes</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			<!-- /Page Wrapper -->
		</div>
		<!-- /Main Wrapper -->
		<!-- jQuery -->
		
<?php echo $__env->make('layout.partials.settings-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH \\172.16.3.6\HTDOCS\cubeportal\resources\views/settings.blade.php ENDPATH**/ ?>