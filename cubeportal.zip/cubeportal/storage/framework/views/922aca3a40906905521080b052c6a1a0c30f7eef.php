<?php echo $__env->make('layout.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Page Wrapper -->
<div class="page-wrapper">
	<!-- Page Content -->
	<div class="content container-fluid">
		<!-- Page Header -->
		<div class="page-header">
			<div class="row align-items-center">
				<div class="col">
					<h3 class="page-title">Employee</h3>
					<ul class="breadcrumb">
						<li class="breadcrumb-item"><a href="index">Dashboard</a></li>
						<li class="breadcrumb-item active">Employee</li>
					</ul>
				</div>
			</div>
		</div>

		<!-- /Page Header -->
		<!-- Search Filter -->
		<form action="<?php echo e(route('createemployees')); ?>" method="post" id="contact" enctype="multipart/form-data"> <?php echo csrf_field(); ?>
			<div id="wizard">
				<h3>
					<div class="media">
						<div class="bd-wizard-step-icon"><i class="la la-user" aria-hidden="true"></i></div>
						<div class="media-body">
							<div class="bd-wizard-step-title">Personal Details</div>
							<div class="bd-wizard-step-subtitle">Step 1</div>
						</div>
					</div>
				</h3>
				<section>
					<div class="">
						<div class="row">
							<div class="col-md-12 col-lg-12 col-xl-3">
								<div class="avatar-upload">
									<div class="avatar-edit">
										<input type='file' id="imageUpload" accept=".png, .jpg, .jpeg" name="profile_image" />
										<label for="imageUpload"></label>
									</div>
									<div class="avatar-preview">
										<div id="imagePreview" style="background-image: url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjvSTK_NBkd5pfKXkHNmHkq-cpJMmgRCCDZg&usqp=CAU);"> </div>
									</div>
								</div>
							</div>
							<div class="col-md-12 col-lg-12 col-xl-9">
								<div class="row">
									<div class="col-md-4 ">
										<div class="form-group">
											<label class="col-form-label">First Name <span class="text-danger">*</span></label>
											<input class="form-control required" type="text" name="first_name">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="col-form-label">Last Name <span class="text-danger">*</span></label>
											<input class="form-control required" type="text" name="last_name">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="col-form-label">Company Code<span class="text-danger">*</span></label>
											<select class="form-control required " name="company_code">
												<option value="">-- Select --</option> <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($company->company_code); ?>"> <?php echo e($company->company_name); ?> </option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="col-form-label">Department<span class="text-danger">*</span></label>
											<select class="form-control required" name="department">
												<option value="">-- Select --</option> <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($department->id); ?>"><?php echo e($department->department_name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="col-form-label">Designation<span class="text-danger">*</span></label>
											<select class="form-control required" name="role">
												<option value="">-- Select --</option> <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $design): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($design->id); ?>"> <?php echo e($design->role_type); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="col-form-label">Shift<span class="text-danger">*</span></label>
											<select class="form-control required " name="shift">
												<option value="">-- Select --</option> <?php $__currentLoopData = $shifts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($shift->id); ?>"><?php echo e($shift->shift_name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="col-form-label">Gender<span class="text-danger">*</span></label>
											<select class="form-control required " name="gender">
												<option value="">-- Select --</option>
												<option value="Male">Male</option>
												<option value="Female">Female</option>
												<option value="Transgender">Transgender</option>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="col-form-label">Marital<span class="text-danger">*</span></label>
											<select class="form-control required " name="marital">
												<option value="">-- Select --</option>
												<option value="Unmarried">Unmarried</option>
												<option value="Married">Married</option>
											</select>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label class="col-form-label">Personal Email <span class="text-danger">*</span></label>
											<input class="form-control required" type="email" name="personal_email">
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label class="col-form-label">Reported to<span class="text-danger">*</span></label>
									<select class="form-control required " name="reported">
										<option value="">-- Select --</option>
										<option value="Manikandan">Manikandan</option>
										<option value="Thamilselvan">Thamilselvan</option>
									</select>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="col-form-label">Phone Number<span class="text-danger">*</span></label>
									<input class="form-control required" id="phone_number" type="text" name="phone_number">
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="col-form-label">Alternative Number <span class="text-muted ml-1"> (optional) </span></label>
									<input class="form-control" type="text" name="alt_number">
								</div>
							</div>
							
							<div class="col-md-3">
								<div class="form-group">
									<label class="col-form-label">Nationality <span class="text-danger">*</span></label>
									<input class="form-control required" type="text" name="nationality">
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="col-form-label">Religion<span class="text-danger">*</span></label>
									<input class="form-control required" type="text" name="religion">
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="col-form-label">Date of Birth <span class="text-danger">*</span></label>
									<div class="cal-icon">
										<input class="form-control required datepicker" type="text" name="dob">
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="col-form-label">Joining Date <span class="text-danger">*</span></label>
									<div class="cal-icon">
										<input class="form-control required datepicker" type="text" name="join_date">
									</div>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="col-form-label">Blood group<span class="text-danger">*</span></label>
									<input type="text" class="form-control required" name="blood_group">
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="col-form-label">Mother tongue <span class="text-danger">*</span></label>
									<input type="text" class="form-control required" name="mother_tongue">
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="col-form-label">Mode of transport <span class="text-danger">*</span></label>
									<input type="text" class="form-control required" name="mode_of_transport">
								</div>
							</div>
							<div class="col-md-3">
								<label class="col-form-label">Family Image <span class="text-muted ml-1"> (optional) </span></label>
								<div class="form-group">
									<input class="form-control " type="file" name="family_image">
								</div>
							</div>
						</div>
					</div>
					<div class="address">

						<div class="card card-ad">
							<div class="card-body">
								<h3 class="card-title">Residence Address </h3>
								<div class="row">


									<div class="col-md-2">
										<div class="form-group">
											<label class="col-form-label">Door No <span class="text-danger">*</span></label>
											<input class="form-control required" type="text" id="door-field" name="residence_permanent_door">
										</div>
									</div>
									<div class="col-md-2">
										<div class="form-group">
											<label class="col-form-label">Street <span class="text-danger">*</span></label>
											<input class="form-control required" id="street-field" type="text" name="residence_permanent_street">
										</div>
									</div>
									<div class="col-md-2">
										<div class="form-group">
											<label class="col-form-label">Pincode<span class="text-danger">*</span></label>
											<input class="form-control required pincode-api" type="text" id="pincode-field" name="residence_permanent_pincode">
										</div>
									</div>
									<div class="col-md-2">
										<div class="form-group">
											<label class="col-form-label">State<span class="text-danger">*</span></label>
											<input class="form-control required state-api" type="text" id="state-field" name="residence_permanent_state" readonly>
										</div>
									</div>

									<div class="col-md-2">
										<div class="form-group">
											<label class="col-form-label">City<span class="text-danger">*</span></label>
											<input class="form-control required city-api" type="text" id="city-field" name="residence_permanent_city" readonly>
										</div>


									</div>
									<div class="col-md-2">
										<div class="form-group">
											<label class="col-form-label">Country<span class="text-danger">*</span></label>
											<input class="form-control required country-api" id="country-field" type="text" name="residence_permanent_country" readonly>
										</div>
									</div>


								</div>
							</div>
						</div>
					</div>
					<div class="mb-3">
					<input type="checkbox" id="check-address" class="mr-2" name="check-address">  Is residence address same as permanent address?
					</div>
					<div class="card card-ad">
						<div class="card-body">
							<h3 class="card-title">Permanent Address </h3>
							<div class="row">
								<div class="col-md-2">
									<div class="form-group">
										<label class="col-form-label">Door No <span class="text-danger">*</span></label>
										<input class="form-control required" id="door-field1" type="text" name="emp_permanent_door">
									</div>
								</div>
								<div class="col-md-2">
									<div class="form-group">
										<label class="col-form-label">Street <span class="text-danger">*</span></label>
										<input class="form-control required" type="text"  id="street-field1" name="emp_permanent_street">
									</div>
								</div>
								<div class="col-md-2">
									<div class="form-group">
										<label class="col-form-label">Pincode<span class="text-danger">*</span></label>
										<input class="form-control required pincode-permanent-api"  id="pincode-field1" type="text" name="emp_permanent_pincode">
									</div>
								</div>
								<div class="col-md-2">
									<div class="form-group">
										<label class="col-form-label">State<span class="text-danger">*</span></label>
										<input class="form-control required state-permanent-api"  id="state-field1" type="text" name="emp_permanent_state" readonly>
									</div>
								</div>

								<div class="col-md-2">
									<div class="form-group">
										<label class="col-form-label">City<span class="text-danger">*</span></label>
										<input class="form-control required city-permanent-api" id="city-field1" type="text" name="emp_permanent_city" readonly>
									</div>


								</div>
								<div class="col-md-2">
									<div class="form-group">
										<label class="col-form-label">Country<span class="text-danger">*</span></label>
										<input class="form-control required country-permanent-api" id="country-field1" type="text" name="emp_permanent_country" readonly>
									</div>
								</div>


							</div>
						</div>
					</div>
		
			</section>
			<h3>
				<div class="media">
					<div class="bd-wizard-step-icon"><i class="la la-users" aria-hidden="true"></i></div>
					<div class="media-body">
						<div class="bd-wizard-step-title">Family Details</div>
						<div class="bd-wizard-step-subtitle">Step 2</div>
					</div>
				</div>
			</h3>
			<section>
				<div class="">
					<table class="table table-bordered mt-3 table-nowrap table-responsive-lg custom-tables" id="productTable">
						<thead>
							<tr>
								<th class="">Relationship type <span class="text-danger">*</span></th>
								<th class="">Name <span class="text-danger">*</span></th>
								<th class="">DoB <span class="text-muted ml-1"> (optional) </span></th>
								<th class="">Phone number<span class="text-danger">*</span></th>
								<th class="">Occupation <span class="text-danger">*</span></th>
								<th class="">Aadhar Number <span class="text-danger">*</span></th>
								<th class="">Aadhar File <span class="text-danger">*</span></th>
								<th class="align-middle position-relative" width="70px"> <a class="btn btn-info text-white border-rounded position-absolute mt-28px ml-1" id="addProduct"><i class="fa fa-plus" aria-hidden="true"></i></a> </th>
							</tr>
						</thead>
						<tbody class="familybody">
							<tr>
							<td class="p-0">
									<div class="form-group mb-0">
									
									<select class="form-control required " name="family_relationship[]">
										<option value="">-- Select --</option>
										<option value="Father">Father</option>
										<option value="Mother">Mother</option>
										<option value="Sister">Sister</option>
										<option value="Brother">Brother</option>
										<option value="Daughter">Daughter</option>
										<option value="Emergency">Emergency</option>
										<option value="Emergency">Son</option>
									</select>
									</div>
								</td>
								<td class="p-0">
									<div class="form-group mb-0">
										<input class="form-control required" type="text" name="family_person_name[]">
									</div>
								</td>
								
								<td class="p-0">
									<div class="form-group mb-0">
										<div class="cal">
											<input class="form-control " type="date" name="family_dob[]">
										</div>
									</div>
								</td>
								<td class="p-0">
									<div class="form-group mb-0">
										<input class="form-control" type="text" name="family_phone_number[]">
									</div>
								</td>
								<td class="p-0">
									<div class="form-group mb-0">
										<input class="form-control required" type="text" name="family_occupation[]">
									</div>
								</td>
								<td class="p-0">
									<div class="form-group mb-0">
										<input class="form-control" type="text" name="family_aadhar_number[]">
									</div>
								</td>
								<td class="p-0">
									<div class="form-group mb-0">
										<input class="form-control" type="file" name="family_aadhar_file[]">
									</div>
								</td>
								<td class="p-0"> </td>
							</tr>
						</tbody>
					</table>
				</div>
			</section>
			<h3>
				<div class="media">
					<div class="bd-wizard-step-icon"><i class="la la-book" aria-hidden="true"></i></div>
					<div class="media-body">
						<div class="bd-wizard-step-title">Educational Details</div>
						<div class="bd-wizard-step-subtitle">Step 3</div>
					</div>
				</div>
			</h3>
			<section>
				<div class="">
					<table class="table table-bordered mt-3 table-nowrap table-responsive-lg custom-tables" id="productTable">
						<thead>
							<tr>
								<th class="">Degree / Certificate<span class="text-danger">*</span></th>
								<th class="">Institute <span class="text-danger">*</span></th>
								<th class="">University / Board <span class="text-danger">*</span></th>
								<th class="">Year of Passing <span class="text-danger">*</span></th>
								<th class="">Percentage <span class="text-danger">*</span></th>
								<th class="align-middle position-relative" width="70px"> <a class="btn btn-info text-white border-rounded position-absolute mt-28px ml-1" id="addeducation"><i class="fa fa-plus" aria-hidden="true"></i></a> </th>
							</tr>
						</thead>
						<tbody class="education-body">
							<tr>
								<td class="p-0">
									<div class="form-group mb-0">
										<input class="form-control required" type="text" name="degree[]">
									</div>
								</td>
								<td class="p-0">
									<div class="form-group mb-0">
										<input class="form-control required" type="text" name="institute[]">
									</div>
								</td>
								<td class="p-0">
									<div class="form-group mb-0">
										<input class="form-control required" type="text" name="university_board[]">
									</div>
								</td>
								<td class="p-0">
									<div class="form-group mb-0">
										<input class="form-control required" type="text" name="year_passed_out[]">
									</div>
								</td>
								<td class="p-0">
									<div class="form-group mb-0">
										<input class="form-control required" type="text" name="percentage[]">
									</div>
								</td>
								<td class="p-0"> </td>
							</tr>
						</tbody>
					</table>
				</div>
			</section>
			<h3>
				<div class="media">
					<div class="bd-wizard-step-icon"><i class="la la-book" aria-hidden="true"></i></div>
					<div class="media-body">
						<div class="bd-wizard-step-title">Experience</div>
						<div class="bd-wizard-step-subtitle">Step 3</div>
					</div>
				</div>
			</h3>
			<section>
				<div class="">
					<div class="content container-fluid">
						<div class="yes">
							<label> <span>Are you experienced or not ?</span>
								<input type="checkbox" checked="checked" id="yesorno" /> </label>
						</div>
						<div class="form form-ex">
							<div class="card-append">
								<div class="card">
									<div class="card-body">
										<h3 class="card-title">Experience Informations <a href="javascript:void(0);" class="delete-icon"><i class="fa fa-trash-o"></i></a></h3>
										<div class="row">
											<div class="col-md-4">
												<div class="form-group">
													<label class="col-form-label">Company name <span class="text-danger">*</span></label>
													<input type="text" class="form-control required " name="exp_company_name[]" value="">
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label class="col-form-label">Location <span class="text-danger">*</span></label>
													<input type="text" class="form-control required" name="exp_location[]" value="">
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label class="col-form-label"> Job Position <span class="text-danger">*</span></label>
													<input type="text" class="form-control required" name="exp_position[]" value="">
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label class="col-form-label">Period From <span class="text-danger">*</span></label>
													<div class="cal">
														<input type="date" class="form-control required" name="exp_period_from[]" value="">
													</div>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group">
													<label class="col-form-label">Period To <span class="text-danger">*</span></label>
													<div class="cal">
														<input type="date" class="form-control required" name="exp_period_to[]" value="">
													</div>
												</div>
											</div>
											<div class="col-md-4">
												<div class="form-group ">
													<div class="">
														<label class="col-form-label">File <span class="text-danger">*</span></label>
														<input type="file" class="form-control required" name="experience_file[]" value="">
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="add-more"> <a class="add-more"><i class="fa fa-plus-circle"></i> Add More</a> </div>
						</div>
					</div>
			</section>
			<h3>
				<div class="media">
					<div class="bd-wizard-step-icon"><i class="la la-money" aria-hidden="true"></i></div>
					<div class="media-body">
						<div class="bd-wizard-step-title">Documents</div>
						<div class="bd-wizard-step-subtitle">Step 4</div>
					</div>
				</div>
			</h3>
			<section>
				<div class="">
					<table class="table table-bordered mt-3 table-nowrap table-responsive-lg custom-tables" id="productTable">
						<thead>
							<tr>
								<th class="">Card type<span class="text-danger">*</span></th>
								<th class="">Card Number<span class="text-danger">*</span></th>
								<th class="">File <span class="text-danger">*</span></th>
								<th class="align-middle position-relative" width="70px"> <a class="btn btn-info text-white border-rounded position-absolute mt-28px ml-1" id="addproof"><i class="fa fa-plus" aria-hidden="true"></i></a> </th>
							</tr>
						</thead>
						<tbody class="proof">
							<tr>
								<td class="p-0">
									<div class="form-group mb-0">
										<select class="form-control select" name="emp_card_type[]">
											<option>Select</option>
											<option value="Pancard">Pan card</option>
											<option value="Aadhar">Aadhar</option>
											<option value="Passport">Passport</option>
											<option value="Education Documents">Education Documents</option>
										</select>
									</div>
								</td>
								<td class="p-0">
									<div class="form-group mb-0">
										<input class="form-control" type="text" name="emp_card_number[]">
									</div>
								</td>
								<td class="p-0">
									<div class="form-group mb-0">
										<input class="form-control" type="file" name="emp_upload_file[]">
									</div>
								</td>
								<td class="p-0"> </td>
							</tr>
						</tbody>
					</table>
				</div>
			</section>
			<h3>
				<div class="media">
					<div class="bd-wizard-step-icon"><i class="la la-money" aria-hidden="true"></i></div>
					<div class="media-body">
						<div class="bd-wizard-step-title">Bank Details</div>
						<div class="bd-wizard-step-subtitle">Step 4</div>
					</div>
				</div>
			</h3>
			<section>
				<div class="">
					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<label class="col-form-label">Account Holder Name<span class="text-danger">*</span></label>
								<input class="form-control required" type="text" name="account_name">
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label class="col-form-label">Bank name<span class="text-danger">*</span></label>
								<input class="form-control required" type="text" name="bank_name">
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label class="col-form-label">Account Number <span class="text-danger">*</span></label>
								<input class="form-control required" type="text" name="account_no">
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label class="col-form-label">Ifsc code<span class="text-danger">*</span></label>
								<input class="form-control required" type="text" name="ifsc">
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label class="col-form-label">Branch Name<span class="text-danger">*</span></label>
								<input class="form-control required" type="text" name="branch_name">
							</div>
						</div>
					</div>
					<button class="btn form-submit mt-4">Submit</button>
				</div>
			</section>
	</div>
	</form>
</div>
<!-- /Page Wrapper --><?php echo $__env->make('layout.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cubeportal\resources\views/employees.blade.php ENDPATH**/ ?>