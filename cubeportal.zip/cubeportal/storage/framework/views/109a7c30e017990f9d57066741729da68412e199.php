
<?php $__env->startSection('content'); ?>
	<!-- Page Wrapper -->
	<div class="page-wrapper">
	<!-- Page Content -->
      <div class="content container-fluid">
      <div class="page-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h3 class="page-title">Company Details</h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index">Dashboard</a></li>
                                <li class="breadcrumb-item active">Company Details</li>
                            </ul>
                        </div>
                        <div class="col-auto float-right ml-auto">
                            <a href="#" class="btn add-btn" data-toggle="modal" data-target="#add_companydetails"><i class="fa fa-plus"></i> Add new</a>
                        </div>
                    </div>
                </div>

                <div class="card mb-0">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="profile-view">
                                    <div class="profile-img-wrap mt-lg-5 mt-md-5">
                                        <div class="profile-img">
                                            <a href="#"><img alt="" src="img/New Project.png"></a>
                                        </div>
                                    </div>
                                    <div class="profile-basic">
                                        <div class="row align-items-center">
                                            <div class="col-md-5">
                                            <div class="profile-info-left">
                                                    <h3 class="user-name m-t-0 w-75">Cube45 eCommerce Services Pvt Ltd</h3>
                                                    <div class="staff-id"> Code : CU</div>
                                                    <div class="text mt-1">www.cube45.com</div>

                                                </div>
                                            </div>
                                            <div class="col-md-7">
                                                <ul class="personal-info">
                                                <li>
                                                        <div class="title">Contact person:</div>
                                                        <div class="text"><a href=""  class="text">Billa</a></div>
                                                    </li>
                                                    <li>
                                                        <div class="title">Phone:</div>
                                                        <div class="text"><a href=""  class="text">9876543210</a></div>
                                                    </li>
                                                    <li>
                                                        <div class="title">Mobile Number</div>
                                                        <div class="text">554234a26</div>
                                                    </li>   
                                                    <li>
                                                        <div class="title">Fax</div>
                                                        <div class="text">55423426</div>
                                                    </li>
                                                
                                                    <li>
                                                        <div class="title">Email:</div>
                                                        <div class="text"><a href="" class="text">johndoe@example.com</a></div>
                                                    </li>
                                                   
                                                    <li>
                                                        <div class="title">Address:</div>
                                                        <div class="text">100 Lakeview Estate, Manchester Township, 
                                                            <br>Chennai, Tamilnadu, India - 600116</div>
                                                    </li>
                                                   
                                             
                                              
                                                  
                                                 
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="pro-edit"><a href="company-edit" class="edit-icon" href="#"><i class="fa fa-pencil"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
           
            <div id="add_companydetails" class="modal custom-modal fade" style="display: none;" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit details</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form>
                                <div class="form-group">
                                    <label>Company Name <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text">
                                </div>
                                <div class="form-group">
                                    <label>Contact person <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text">
                                </div>
                                <div class="row"><div class="col-md-6">
                                <div class="form-group">
                                    <label>Company code <span class="text-danger">*</span></label>
                                      <input class="form-control" type="text">
</div></div><div class="col-md-6">
                                <div class="form-group">
                                    <label>Email <span class="text-danger">*</span></label>
                                      <input class="form-control" type="text">
</div>
</div></div>
<div class="form-group">
                                    <label>Fax Number <span class="text-danger">*</span></label>
                                    <input class="form-control" type="text">
                                </div>
<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<label>Address</label>
									<input class="form-control " name="door_no" value="" type="text">
								</div>
							</div>
							<div class="col-sm-6 col-md-6 col-lg-6">
								<div class="form-group">
									<label>Country</label>
									<select class="form-control select" name="country">
										<option>USA</option>
										<option>United Kingdom</option>
									</select>
								</div>
							</div>
							<div class="col-sm-6 col-md-6 col-lg-6">
								<div class="form-group">
									<label>City</label>
									<select class="form-control select" name="city">
										<option>Chennai</option>
										<option>Trichy</option>
									</select>
								</div>
							</div>
							<div class="col-sm-6 col-md-6 col-lg-6">
								<div class="form-group">
									<label>State/Province</label>
									<select class="form-control select" name="state">
										<option>California</option>
										<option>Alaska</option>
										<option>Alabama</option>
									</select>
								</div>
							</div>
							<div class="col-sm-6 col-md-6 col-lg-6">
								<div class="form-group">
									<label>Postal Code</label>
									<input class="form-control" name="postal_code" value="" type="text">
								</div>
							</div>
						</div>
                        <div class="row">
							<div class="col-md-6">
                                <div class="form-group">
                                    <label>Phone Number <span class="text-danger">*</span></label>
                                      <input class="form-control" type="text">
</div>
</div>
							<div class="col-md-6">
                         
                                <div class="form-group">
                                    <label>Mobile Number <span class="text-danger">*</span></label>
                                      <input class="form-control" type="text">
</div>
</div></div>
<div class="form-group">
                                    <label>Website url <span class="text-danger">*</span></label>
                                      <input class="form-control" type="text">
</div>
                      
                                <div class="submit-section">
                                    <button class="btn btn-primary submit-btn">Save Changes</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
<!-- /Page Wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cubeportal\resources\views/settings-custom.blade.php ENDPATH**/ ?>