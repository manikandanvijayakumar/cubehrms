<script src="js/jquery-3.5.1.min.js"></script>
		<!-- Bootstrap Core JS -->
		<script src="js/popper.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<!-- Slimscroll JS -->
		<script src="js/jquery.slimscroll.min.js"></script>
		<!-- Select2 JS -->
		<script src="js/select2.min.js"></script>
		<!-- Custom JS -->
		<script src="js/app.js"></script>
</body>

</html><?php /**PATH \\172.16.3.6\HTDOCS\cubeportal\resources\views/layout/partials/settings-footer.blade.php ENDPATH**/ ?>