<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFamiliesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('families', function (Blueprint $table) {
            $table->id();
            $table->string('emp_id', 50);
            $table->string('person_name', 30);
            $table->string('relationship', 30);
            $table->date('dob')->nullable();
            $table->string('phone_number')->nullable();
            $table->string('occupation', 40)->nullable();
            $table->string('aadhar_number', 20)->nullable();
            $table->text('aadhar_image')->nullable();
            $table->text('aadhar_path')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('families');
    }
}
