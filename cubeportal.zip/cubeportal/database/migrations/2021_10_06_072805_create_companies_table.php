<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCompaniesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('companies', function (Blueprint $table) {
            $table->bigIncrements('id')->unsigned();
            $table->string('company_code')->unique();
            $table->string('company_name')->unique();
            $table->string('contact_person')->nullable();
            $table->string('door_no');
            $table->string('city');
            $table->string('state');
            $table->string('country');
            $table->string('postal_code');
            $table->string('email');
            $table->string('phone_number')->nullable();
            $table->string('mobile_number');
            $table->string('fax')->nullable();
            $table->string('website_url')->unique();
            $table->string('company_image')->nullable();
            $table->text('image_path')->nullable();
            $table->tinyInteger('status')->default('1');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('companies');
    }
}
