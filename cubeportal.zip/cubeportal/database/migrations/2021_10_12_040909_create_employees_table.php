<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployeesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->id();
            $table->string('emp_roll', 50)->unique();
            $table->string('first_name', 30);
            $table->string('last_name', 30);
            $table->string('gender', 20);
            $table->integer('department_id');
            $table->string('company_code', 20);
            $table->integer('shift_id');
            $table->integer('role_id')->nullable();
            $table->string('reported_to', 70);
            $table->string('personal_email', 70)->unique();
            $table->string('phone_number', 30)->unique();
            $table->string('alt_number', 30)->nullable();
            $table->string('marital', 20);
            $table->string('nationality', 30);
            $table->string('religion', 30);
            $table->string('blood_group', 20)->nullable();
            $table->string('mother_tongue', 30);
            $table->date('dob');
            $table->date('join_date');
            $table->string('mode_of_transport', 30);
            $table->text('profile_image', 150);
            $table->text('profile_image_path');
            $table->text('family_image', 150)->nullable();
            $table->text('family_image_path')->nullable();
            $table->tinyInteger('status')->default('1');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employees');
    }
}
