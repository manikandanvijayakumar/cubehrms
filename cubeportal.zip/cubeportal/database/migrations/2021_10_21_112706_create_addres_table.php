<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAddresTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('addres', function (Blueprint $table) {
            $table->id();
            $table->string('emp_id', 50);
            $table->string('address_type', 100)->nullable();
            $table->string('door_no', 50)->nullable();
            $table->string('street', 350)->nullable();
            $table->string('city', 75)->nullable();
            $table->string('state', 70)->nullable();
            $table->string('country', 70)->nullable();
            $table->string('pincode', 50)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('addres');
    }
}
