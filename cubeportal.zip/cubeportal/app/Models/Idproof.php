<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Idproof extends Model
{
    use HasFactory;
    protected $fillable = ([
        'emp_id',
        'id_card_type',
        'id_card_number',
        'id_card_file',
        'file_path'
    ]);
}
