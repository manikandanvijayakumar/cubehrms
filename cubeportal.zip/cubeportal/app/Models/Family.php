<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Family extends Model
{
    use HasFactory;
    protected $fillable = ([
        'emp_id',
        'person_name',
        'relationship',
        'dob',
        'occupation',
        'phone_number',
        'aadhar_number',
        'aadhar_image',
        'aadhar_path'
    ]);
}
