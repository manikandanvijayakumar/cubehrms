<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    use HasFactory;
    protected $fillable = ([
        'emp_roll',
        'first_name',
        'last_name',
        'gender',
        'department_id',
        'company_code',
        'shift_id',
        'reported_to',
        'role_id',
        'personal_email',
        'phone_number',
        'alt_number',
        'marital',
        'nationality',
        'religion',
        'blood_group',
        'mother_tongue',
        'dob',
        'join_date',
        'mode_of_transport',
        'profile_image',
        'profile_image_path',
        'family_image',
        'family_image_path'
    ]);
}
