<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Education extends Model
{
    use HasFactory;
    protected $fillable = ([
        'emp_id',
        'degree',
        'institute',
        'university_board',
        'year_of_passing',
        'percentage'
    ]);
}
