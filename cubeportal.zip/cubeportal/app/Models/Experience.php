<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Experience extends Model
{
    use HasFactory;
    protected $fillable = ([
        'emp_id',
        'company_name',
        'location',
        'role',
        'period_from',
        'period_to',
        'experience_file',
        'experience_file_path'
    ]);
}
