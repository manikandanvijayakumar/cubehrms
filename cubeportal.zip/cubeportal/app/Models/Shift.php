<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shift extends Model
{
    use HasFactory;
    protected $fillable = ([
        'shift_name',
        'in_time',
        'out_time',
        'min_in_time',
        'max_in_time',
        'min_out_time',
        'max_out_time',
    ]);
}
