<?php

namespace App\Http\Controllers;

use Brian2694\Toastr\Facades\Toastr;
use App\Models\Company;


use Illuminate\Http\Request;

class CompanyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $Companies = Company::latest()->paginate(5);
        Toastr::success('We have e-mailed your password reset link! :)','Success');
        return view('settings', compact('Companies'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //dd($request);
        $request->validate([
            'company_name' => 'required|min:4',
            'contact_person' => 'required|min:2',
            'company_code' => 'required|min:2',
            'website_url'  => 'required|min:4',
            'door_no' => 'required',
            'postal_code' => 'required|min:4|max:6',
            'phone_number' => 'required|min:4',
            'mobile_number' => 'required|min:4',
            'email' => 'required|min:4',
            'fax' => 'required|min:4',
            'company_image' => 'required',
        ]);
        try{
            $extension = $request->file('company_image')->getClientOriginalExtension();
            $company_image = strtolower($request->company_name).'-'.date('d-M-Y').'-'.time().'.'.$extension;
            $path = 'img/company/';
            $request->file('company_image')->move($path, $company_image);

            $Company = new Company;
            $Company::create([
                //"_token" => $request->get("_token"),
                "company_name" => $request->get('company_name'),
                "company_code" => $request->get('company_code'),
                "contact_person" => $request->get('contact_person'),
                "door_no" => $request->get('door_no'),
                "country" => $request->get('country'),
                "city" => $request->get('city'),
                "state" => $request->get('state'),
                "postal_code" => $request->get('postal_code'),
                "email" => $request->get('email'),
                "phone_number" => $request->get('phone_number'),
                "mobile_number" => $request->get('mobile_number'),
                "fax" => $request->get('fax'),
                "website_url" => $request->get('website_url'),
                "company_image" => $company_image,
                "image_path" => $path
            ]);
        //    dd($Company);
            Toastr::success('Data updated successfully :)','Success');
            return redirect()->back();
        }
        catch(\Exception $e){
            Toastr::error('Data updated fail :)','Error');
            return redirect()->route('settings');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Company  $company
     * @return \Illuminate\Http\Response
     */
    public function show(Company $company)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Company  $company
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $dmf = Company::find($id);
      //  dd($company);
        return view('settings-custom');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Company  $company
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Company $company)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Company  $company
     * @return \Illuminate\Http\Response
     */
    public function destroy(Company $company)
    {
        //
    }
}
