<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Shift;
use App\Models\Role;
use App\Models\Company;
use App\Models\Department;
use App\Models\Family;
use App\Models\Education;
use App\Models\Bank;
use App\Models\Idproof;
use App\Models\Experience;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;

class TestController extends Controller
{
    public function store()
    {
        $employee = new Employee;
        $lastEmployee =  Employee::orderBy('created_at', 'desc')->first();

        if (!$lastEmployee)
            $number = 0;
        else
        $number = substr($lastEmployee->emp_id, 2);
        $empId = 'CU' . sprintf('%04d', intval($number) + 1);
        $req = array(
            array('person_name' => 'Vijayakumar', 'relationship' => 'father', 'dob' => '1964-02-10', 'occupation' => 'press', 'phone_number' =>  '3216547895', 'aadhar_number' => '12346544598798', 'aadhar_image' => 'hkjhkj', 'aadhar_path' => 'hkjhkj'),
            array('person_name' => 'Amsavalli', 'relationship' => 'Mother', 'dob' => '1954-02-10', 'occupation' => 'Home maker', 'phone_number' =>  '3216547895', 'aadhar_number' => '12346544598798', 'aadhar_image' => 'hkjhkj', 'aadhar_path' => 'hkjhkj'),
            array('person_name' => 'Saraswathi', 'relationship' => 'Sister', 'dob' => '1997-05-15', 'occupation' => 'Married', 'phone_number' =>  '3216547895', 'aadhar_number' => '12346544598798', 'aadhar_image' => 'hkjhkj', 'aadhar_path' => 'hkjhkj'),
        );
        $family = new Family;
        foreach ($req as $rs) {
            $family::create([
                'emp_id' => $empId, //generate employee id
                'person_name' => $rs['person_name'],
                'relationship' => $rs['relationship'],
                'dob' => $rs['dob'],
                'occupation' => $rs['occupation'],
                'phone_number' =>  $rs['phone_number'],
                'aadhar_number' => $rs['aadhar_number'],
                'aadhar_image' => $rs['aadhar_image'],
                'aadhar_path' => $rs['aadhar_path']
            ]);
        }
        return 'hello';
    }
}
