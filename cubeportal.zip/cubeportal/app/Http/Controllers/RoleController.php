<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Role;
use Brian2694\Toastr\Facades\Toastr;

class RoleController extends Controller
{
    public function index()
    {
        $roles = Role::all();
        //Toastr::success('We have e-mailed your password reset link! :)','Success');

        return view('roles-permissions', compact('roles'))->with('success', 'Welcome');
    }

    public function store(Request $request)
    {
        $request->validate([
            'role_type' => 'required|unique:roles'
        ]);

        $role = new Role;
        $role::create([
           'role_type' => $request->get('role_type'),
        ]);
        Toastr::success('We have e-mailed your password reset link! :)','Success');
        return redirect()->route('roles-permissions');
    } 
}

