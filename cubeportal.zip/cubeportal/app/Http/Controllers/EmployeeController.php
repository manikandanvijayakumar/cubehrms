<?php

namespace App\Http\Controllers;

use Brian2694\Toastr\Facades\Toastr;
use App\Models\Employee;
use App\Models\Shift;
use App\Models\Role;
use App\Models\Company;
use App\Models\Department;
use App\Models\Addres;
use App\Models\Family;
use App\Models\Education;
use App\Models\Bank;
use App\Models\Idproof;
use App\Models\Experience;
use App\Models\User;
use GrahamCampbell\ResultType\Success;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $designations = Role::all();
        $employees = Employee::join('roles', 'employees.role_id', '=', 'roles.id')->get(['employees.*', 'roles.role_type']);
        return view('employee-list', compact('employees', 'designations'));
    }

    public function profile($id)
    {
        $employees = Employee::join('roles', 'employees.role_id', '=', 'roles.id')->join('departments', 'employees.department_id', '=', 'departments.id')->get(['employees.*', 'roles.role_type', 'departments.department_name']);
        $familyies = Family::where('emp_id', '=', $id)->get();
        $banks = Bank::where('emp_id', '=', $id)->get();
        $education = Education::where('emp_id', '=', $id)->get();
        $experience = Experience::where('emp_id', '=', $id)->get();
        $address = Addres::where('emp_id', '=', $id)->get();
        return view('profile', compact('employees', 'familyies', 'education', 'banks', 'experience', 'address'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $designations = Role::all();
        $companies = Company::all();
        $shifts = Shift::all();
        $departments = Department::all();
        $employees = Employee::all();
        return view('employees', compact('employees', 'departments', 'shifts', 'designations', 'companies'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Generate Employee ID Start
        $lastEmployee =  Employee::orderBy('created_at', 'desc')->first();

        if (!$lastEmployee)
            $number = 0;
        else
            $number = substr($lastEmployee->emp_id, 2);
        $empId = $request->get('company_code') . sprintf('%04d', intval($number) + 1);

        //Generate Employee ID End

        $extension = $request->file('profile_image')->getClientOriginalExtension();
        $profile_image = strtolower($empId) . '-' . date('d-M-Y') . '-' . time() . '.' . $extension;
        $profile_image_path = 'img/'.$empId.'/profile/';
        $request->file('profile_image')->move($profile_image_path, $profile_image);

        $extension = $request->file('family_image')->getClientOriginalExtension();
        $family_image = strtolower($empId) . '-' . date('d-M-Y') . '-' . time() . '.' . $extension;
        $family_image_path = 'img/'.$empId.'/family/';
        $request->file('family_image')->move($family_image_path, $family_image);

        $employee = new Employee;
        $employee::create([
            'emp_roll' => $empId, //generate employee id
            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),
            'gender' => $request->get('gender'),
            'department_id' => $request->get('department'),
            'company_code' => $request->get('company_code'),
            'shift_id' => $request->get('shift'),
            'role_id' => $request->get('role'),
            'reported_to' => $request->get('reported'),
            'personal_email' => $request->get('personal_email'),
            'phone_number' => $request->get('phone_number'),
            'alt_number' => $request->get('alt_number'),
            'marital' => $request->get('marital'),
            'nationality' => $request->get('nationality'),
            'religion' => $request->get('religion'),
            'blood_group' => $request->get('blood_group'),
            'mother_tongue' => $request->get('mother_tongue'),
            'dob' => \Carbon\Carbon::createFromFormat('d/m/Y',  $request->get('dob'))->format('Y-m-d'),
            'join_date' => \Carbon\Carbon::createFromFormat('d/m/Y',  $request->get('join_date'))->format('Y-m-d'),
            'mode_of_transport' => $request->get('mode_of_transport'),
            'profile_image' => $profile_image,
            'profile_image_path' => $profile_image_path,
            'family_image' => $family_image,
            'family_image_path' => $family_image_path
        ]);

        $address = new Addres;
         {
            $address::create([
                'emp_id' => $empId, //generate employee id
                'address_type' => 'Residence Address',
                'door_no' => $request->get('residence_permanent_door'),
                'pincode' => $request->get('residence_permanent_street'),
                'city' => $request->get('residence_permanent_pincode'),
                'state' => $request->get('residence_permanent_state'),
                'city' => $request->get('residence_permanent_city'),
                'country' => $request->get('residence_permanent_country')
            ]);

            $address::create([
                'emp_id' => $empId, //generate employee id
                'address_type' => 'Permanent Address',
                'door_no' => $request->get('emp_permanent_door'),
                'street' => $request->get('emp_permanent_street'),
                'pincode' => $request->get('emp_permanent_pincode'),
                'state' => $request->get('emp_permanent_state'),
                'city' => $request->get('emp_permanent_city'),
                'country' => $request->get('emp_permanent_country')
            ]);
        }
            
        $family = new Family;
        for ($i = 0; $i < count($request->get('family_person_name')); $i++) {

            $extension = $request->file('family_aadhar_file')[$i]->getClientOriginalExtension();
            $family_aadhar_file = strtolower($empId) . '-' . date('d-M-Y') . '-' . time() . '.' . $extension;
            $family_aadhar_file_path = 'img/'.$empId.'/family/idproof';
            $request->file('family_aadhar_file')[$i]->move($family_aadhar_file_path, $family_aadhar_file);

            $family::create([
                'emp_id' => $empId, //generate employee id
                'person_name' => $request->get('family_person_name')[$i],
                'relationship' => $request->get('family_relationship')[$i],
                'dob' => \Carbon\Carbon::createFromFormat('Y-m-d',  $request->get('family_dob')[$i])->format('Y-m-d'),
                'occupation' => $request->get('family_occupation')[$i],
                'phone_number' =>  $request->get('family_phone_number')[$i],
                'aadhar_number' => $request->get('family_aadhar_number')[$i],
                'aadhar_image' => $family_aadhar_file,
                'aadhar_path' => $family_aadhar_file_path
            ]);
        }

        $education = new Education;
        for ($i = 0; $i < count($request->get('degree')); $i++) {
            $education::create([
                'emp_id' => $empId, //generate employee id
                'degree' => $request->get('degree')[$i],
                'institute' => $request->get('institute')[$i],
                'university_board' => $request->get('university_board')[$i],
                'year_of_passing' => $request->get('year_passed_out')[$i],
                'percentage' => $request->get('percentage')[$i]
            ]);
        }

        $experience = new Experience;

        for ($i = 0; $i < count($request->get('exp_company_name')); $i++) {

            $extension = $request->file('experience_file')[$i]->getClientOriginalExtension();
            $experience_file = strtolower($empId) . '-' . date('d-M-Y') . '-' . time() . '.' . $extension;
            $experience_file_path = 'img/'.$empId.'/experience/';
            $request->file('experience_file')[$i]->move($experience_file_path, $experience_file);


            $experience::create([
                'emp_id' => $empId, //generate employee id
                'company_name' => $request->get('exp_company_name')[$i],
                'location' => $request->get('exp_location')[$i],
                'role' => $request->get('exp_position')[$i],
                'period_from' => \Carbon\Carbon::createFromFormat('Y-m-d',  $request->get('exp_period_from')[$i])->format('Y-m-d'),
                'period_to' => \Carbon\Carbon::createFromFormat('Y-m-d',  $request->get('exp_period_to')[$i])->format('Y-m-d'),
                'experience_file' => $experience_file,
                'experience_file_path' => $experience_file_path
            ]);
        }


        $idproof = new Idproof;
        for ($i = 0; $i < count($request->get('emp_card_type')); $i++) {

            $extension = $request->file('emp_upload_file')[$i]->getClientOriginalExtension();
            $emp_cards = strtolower($empId) . '-' . date('d-M-Y') . '-' . time() . '.' . $extension;
            $emp_cards_path = 'img/'.$empId.'/documents/';
            $request->file('emp_upload_file')[$i]->move($emp_cards_path, $emp_cards);

            $idproof::create([
                'emp_id' => $empId, //generate employee id
                'id_card_type' => $request->get('emp_card_type')[$i],
                'id_card_number' => $request->get('emp_card_number')[$i],
                'id_card_file' => $emp_cards,
                'file_path' => $emp_cards_path,
            ]);
        }


        $bank = new Bank;

        $bank::create([
            'emp_id' => $empId, //generate employee id
            'account_name' => $request->get('account_name'),
            'account_number' => $request->get('account_no'),
            'bank_name' => $request->get('bank_name'),
            'ifsc_code' => $request->get('ifsc'),
            'branch_name' => $request->get('branch_name')
        ]);

        $user = new User;
        $user::create([
            'emp_id' => $empId,
            'email' => $request->get('personal_email'),
            'password' => Hash::make('cube@143')
        ]);

       
        //dd($request);
         return 'Success';
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function show(Employee $employee)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function edit(Employee $employee)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Employee $employee)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Employee  $employee
     * @return \Illuminate\Http\Response
     */
    public function destroy(Employee $employee)
    {
        //
    }
}
